<?php
define('BACKUP_PATH', __DIR__ . '/../backup');
define('WP_PATH', '/var/www/web/wordpress'); // Ajustar según la ubicación de WordPress
?>